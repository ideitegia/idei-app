package ar.delucas.sudoku.exceptions;

public class MalformedSudokuException extends RuntimeException {

	private static final long serialVersionUID = 4443123588987137893L;

}
